# yelp_ingest_lambda.py
# Ingestion Lambda: fetches Yelp businesses for selected cuisines, writes to DynamoDB, indexes in OpenSearch
import os
import json
import time
import logging
import requests
import boto3
from urllib.parse import urlencode
from datetime import datetime
from requests_aws4auth import AWS4Auth
from decimal import Decimal

logger = logging.getLogger()
logger.setLevel(logging.INFO)

YELP_API_KEY = os.environ.get('YELP_API_KEY')
DYNAMO_TABLE = os.environ.get('DYNAMO_TABLE', 'yelp-restaurants')
OPENSEARCH_ENDPOINT = os.environ.get('OPENSEARCH_ENDPOINT')  # e.g. https://search-...es.amazonaws.com
REGION = os.environ.get('AWS_REGION', 'us-east-1')

if not YELP_API_KEY:
    raise Exception("YELP_API_KEY env var must be set")

HEADERS = {"Authorization": f"Bearer {YELP_API_KEY}"}
dynamodb = boto3.resource('dynamodb', region_name=REGION)
table = dynamodb.Table(DYNAMO_TABLE)
session = boto3.Session()
credentials = session.get_credentials().get_frozen_credentials()
awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, REGION, 'es', session_token=credentials.token)

# default cuisines and neighborhoods (Manhattan)
CUISINES = os.environ.get('CUISINES', 'Japanese,Italian,Chinese,Mexican,Indian').split(',')
NEIGHBORHOODS = os.environ.get('NEIGHBORHOODS', 'Manhattan').split(',')

YELP_SEARCH_URL = "https://api.yelp.com/v3/businesses/search"
# Yelp limit per request is 50
YELP_LIMIT = 50

def fetch_businesses_for_term(term, location='Manhattan, NY', total_needed=200):
    businesses = {}
    offset = 0
    while len(businesses) < total_needed:
        params = {
            "term": term,
            "location": location,
            "limit": YELP_LIMIT,
            "offset": offset
        }
        url = YELP_SEARCH_URL + "?" + urlencode(params)
        r = requests.get(url, headers=HEADERS)
        if r.status_code == 429:
            # rate limited — back off
            logger.warning("Yelp rate limited, sleeping 5s")
            time.sleep(5)
            continue
        if r.status_code != 200:
            logger.error("Yelp error: %s %s", r.status_code, r.text)
            break
        data = r.json()
        items = data.get('businesses', [])
        if not items:
            break
        for b in items:
            businesses[b['id']] = b
        offset += YELP_LIMIT
        # Yelp may limit offsets (usually to 1000); break if offset too large
        if offset >= 1000:
            logger.info("Reached Yelp offset limit, stopping pagination for term: %s", term)
            break
        # small polite sleep to avoid hitting rate limits
        time.sleep(0.3)
    return list(businesses.values())

def save_to_dynamo(b):
    # Helper to safely convert floats to Decimal (DynamoDB requirement)
    def safe_decimal(value):
        if value is None:
            return None
        try:
            return Decimal(str(value))
        except Exception:
            return value  # leave as-is if not numeric

    coords = b.get("coordinates", {})
    item = {
        "business_id": b.get("id"),
        "Name": b.get("name"),
        "Address": " ".join(b.get("location", {}).get("display_address", [])),
        "Coordinates": {
            "latitude": safe_decimal(coords.get("latitude")),
            "longitude": safe_decimal(coords.get("longitude"))
        },
        "NumReviews": int(b.get("review_count", 0)),
        "Rating": safe_decimal(b.get("rating", 0.0)),
        "ZipCode": b.get("location", {}).get("zip_code", ""),
        "Categories": [c.get("title") for c in b.get("categories", [])],
        "Phone": b.get("phone", ""),
        "insertedAtTimestamp": datetime.utcnow().isoformat()
    }

    # Put item into DynamoDB
    try:
        table.put_item(Item=item)
    except Exception as e:
        logger.exception("DynamoDB put_item failed for %s", b.get("id"))
        raise

def index_to_opensearch(b):
    if not OPENSEARCH_ENDPOINT:
        logger.warning("OPENSEARCH_ENDPOINT not set; skipping index")
        return
    cuisine_list = [c.get('title') for c in b.get('categories', [])]
    # minimal doc
    doc = {
        "RestaurantID": b.get("id"),
        "Name": b.get("name"),
        "Cuisine": cuisine_list,
        "ZipCode": b.get("location", {}).get("zip_code", "")
    }
    url = OPENSEARCH_ENDPOINT.rstrip('/') + "/restaurants/_doc/" + b.get("id")
    headers = {"Content-Type": "application/json"}
    try:
        r = requests.put(url, auth=awsauth, json=doc, headers=headers, timeout=30)
        if r.status_code not in (200,201):
            logger.error("OpenSearch index error %s %s", r.status_code, r.text)
            # optionally handle errors (retry)
    except Exception:
        logger.exception("Failed to index to OpenSearch for %s", b.get("id"))
        raise

def handler(event, context):
    logger.info("Starting Yelp ingest Lambda")
    total_added = 0
    # iterate cuisines + neighborhoods
    for cuisine in CUISINES:
        cuisine = cuisine.strip()
        term = f"{cuisine} restaurant"
        logger.info("Fetching for %s", term)
        for neighborhood in NEIGHBORHOODS:
            loc = neighborhood.strip()
            businesses = fetch_businesses_for_term(term, location=loc, total_needed=200)
            logger.info("Fetched %d businesses for %s in %s", len(businesses), cuisine, loc)
            for b in businesses:
                try:
                    save_to_dynamo(b)
                    index_to_opensearch(b)
                    total_added += 1
                except Exception:
                    logger.exception("Failed to save/index business %s", b.get("id"))
    logger.info("Ingest complete. Total added/updated: %d", total_added)
    return {"status": "ok", "added": total_added}
