import boto3, requests, json
from requests_aws4auth import AWS4Auth

region = 'us-east-1'
service = 'es'
credentials = boto3.Session().get_credentials().get_frozen_credentials()
awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, region, service, session_token=credentials.token)

endpoint = "https://search-restaurants-domain-wcljgs6k6zzwyy7hadpuientvu.us-east-1.es.amazonaws.com"
url = endpoint + "/restaurants/_search"
q = {"query":{"match":{"Cuisine":"Japanese"}},"size":5}
r = requests.get(url, auth=awsauth, json=q)
print(r.status_code, r.text)